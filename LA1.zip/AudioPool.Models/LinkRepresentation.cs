﻿namespace AudioPool.Models
{
    public class LinkRepresentation
	{
		public string Href { get; set; } = "";
	}
}

